class pointsLimit {
    constructor(data = {}) {
        this.pointsAwarded = data.pointsAwarded;
        this.pointsRedeemDate = data.pointsRedeemDate;
    }
}